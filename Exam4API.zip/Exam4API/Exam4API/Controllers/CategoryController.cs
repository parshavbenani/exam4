﻿using Exam4API.DataAccess.Repository.IRepository;
using Exam4API.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Xml.Linq;

namespace Exam4API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CategoryController : ControllerBase
    {
        private readonly IUnitOfWork _unitOfWork;

      
        public CategoryController(IUnitOfWork unitOfWork)
        {
            _unitOfWork = unitOfWork;
        }


        IEnumerable<Category> categories;
        IEnumerable<Product> products;


        [HttpGet]
        public IEnumerable<Category> Get()
        {
            return _unitOfWork.Category.GetAll();
        }


        [Route("Product")]
        [HttpGet]
        public IEnumerable<Product> GetProduct()
        {

            return _unitOfWork.Product.GetAll();

            //var q = (from pd in products
            //         join cd in categories on pd.CategoryId equals cd.CategoryId
            //         select new
            //         {
            //             CategoryName = cd.Name,
            //             pd.Name,
            //             cd.CategoryId,
            //             pd.Quantity,
            //             pd.Price,
            //             pd.Description
            //         }).ToList();
        }


    }
}
