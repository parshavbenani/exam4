﻿namespace Exam4API.Models
{
    public class Order
    {
        public int OrderId { get; set; }
        public DateTime OrderDate { get; set; } 
        public string Note { get; set; }
        public int? DisountAmount { get; set; }
        public string? StatusType { get; set; }
        public double TotalAmount { get; set; }
        public string CustomerName { get; set; }
        public string CustomerEmail { get; set; }
        public string CustomerContactNo { get; set; }
        public bool IsActive { get; set; }
        public DateTime CreatedOn { get; set; } 
        public DateTime ModifiedOn { get; set;} 
    }
}
