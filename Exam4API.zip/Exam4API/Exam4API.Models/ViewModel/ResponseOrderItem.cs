﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ModelView.ViewModel
{
    public class ResponseOrderItem
    {
        public string Message { get; set; }
    }
}
